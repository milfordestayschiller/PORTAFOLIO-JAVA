let promedios = document.getElementById('promedio')
promedios.addEventListener("keyup", function (e) {
    if(e.key === "Enter"){
        let nota = promedios.value;
        console.log(nota)
        let array = []
array.push(nota)
console.log(array)
        promedios.value = ""

      
        
        var inicial=0;

        for(var i=0;i<promedios.length;i++){
        const resultado = promedios[i].value
        console.log(resultado)
        if(parseInt(resultado))
        
            inicial += parseInt(promedios[i].value);
            
    }
    
        
 
    }
})



