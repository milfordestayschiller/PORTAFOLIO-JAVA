
import { asignatura } from "./DataAsignaturas.js"


const result = asignatura.map((a) =>  (a.asignatura1)
    
    )

    const result2 = asignatura.map((a) =>  (a.asignatura2)
    
    )
document.getElementById("asignatura1").innerHTML = result.join("")
document.getElementById("asignatura2").innerHTML = result2.join("")

function Mostrar(el)
{
    var e = document.getElementById(el);
    var strSel = "The Value is: " + e.options[e.selectedIndex].value + " and text is: " + e.options[e.selectedIndex].text;
    alert(strSel);
}

Mostrar()
