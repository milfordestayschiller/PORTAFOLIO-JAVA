export const asignatura = [{
    id: 1,
    asignatura1: "JS"
},
{
    id: 2,
    asignatura2: "JS2" 
}

]