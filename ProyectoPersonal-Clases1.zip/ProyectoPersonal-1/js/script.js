import { asignatura } from "./DataAsignaturas.js";

var array = [];
let promedios = document.getElementById('promedio')
promedios.addEventListener("keyup", function (e) {
    let resultado = promedios.value
    if (e.key === "Enter") {
        array.push(resultado)
        console.log(array)
        promedios.value = ""
        var btn = document.createElement("p");
        var t = document.createTextNode(array.join(" - "))
        btn.appendChild(t);
        document.getElementById("result").appendChild(btn)

        var suma = 0
        for (let index = 0; index < array.length; index++) {
            const element = parseInt(array[index])
            suma += element / array.length
        }
        let calcular = document.getElementById("calcular")
        calcular.addEventListener("click", function (params) {
            document.getElementById("resultado").innerHTML = suma

            btn.parentNode.removeChild(btn)

            let reset = document.getElementById("reset")
            reset.addEventListener("click", function (params) {
                document.getElementById("resultado").innerHTML = array = []
            })

        })
    }
})
/////////////INGRESO ASIGNATURAS /////////




